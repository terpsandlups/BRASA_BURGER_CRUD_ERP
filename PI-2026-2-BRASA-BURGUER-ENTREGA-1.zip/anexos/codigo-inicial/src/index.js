import {Pedido} from "./domain/Pedido.js";

const pedido=new Pedido({
  unidade:"Japy",
  cpf:"52998224725",
  desconto:5,
  taxaEntrega:6,
  itens:[
    {sku:"BUR001",quantidade:2,precoUnitario:29.90,custoUnitario:9.80},
    {sku:"BEB001",quantidade:2,precoUnitario:7.90,custoUnitario:3.00}
  ]
});

console.log(pedido);
