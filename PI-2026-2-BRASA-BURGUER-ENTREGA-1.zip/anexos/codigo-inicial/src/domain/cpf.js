export function validarCPF(valor){
  const cpf=String(valor??"").replace(/\D/g,"");
  if(cpf.length!==11||/^(\d)\1{10}$/.test(cpf))return false;
  const digito=base=>{
    const soma=[...base].reduce((acc,n,i)=>acc+Number(n)*(base.length+1-i),0);
    const resto=(soma*10)%11;
    return resto===10?0:resto;
  };
  return digito(cpf.slice(0,9))===Number(cpf[9])&&digito(cpf.slice(0,10))===Number(cpf[10]);
}
