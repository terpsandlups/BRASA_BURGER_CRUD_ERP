import {calcularPedido} from "./calculos.js";
import {validarCPF} from "./cpf.js";

export class Pedido{
  constructor({unidade,cpf,itens,desconto=0,taxaEntrega=0}){
    if(!unidade)throw new Error("Unidade obrigatória");
    if(!validarCPF(cpf))throw new Error("CPF inválido");
    this.unidade=unidade;
    this.cpf=cpf;
    this.itens=itens;
    this.status="NOVO";
    Object.assign(this,calcularPedido({itens,desconto,taxaEntrega}));
  }
}
