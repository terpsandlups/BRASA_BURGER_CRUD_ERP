const moeda=valor=>Math.round((valor+Number.EPSILON)*100)/100;

export function calcularPedido({itens,desconto=0,taxaEntrega=0}){
  if(!Array.isArray(itens)||itens.length===0)throw new Error("Pedido sem itens");
  let subtotal=0;
  let custo=0;
  for(const item of itens){
    if(!Number.isInteger(item.quantidade)||item.quantidade<=0)throw new Error("Quantidade inválida");
    if(item.precoUnitario<0||item.custoUnitario<0)throw new Error("Valor inválido");
    subtotal+=item.quantidade*item.precoUnitario;
    custo+=item.quantidade*item.custoUnitario;
  }
  const total=Math.max(0,moeda(subtotal-desconto+taxaEntrega));
  custo=moeda(custo);
  const margemBruta=moeda(total-custo);
  return {
    subtotal:moeda(subtotal),total,custo,
    cmvPercentual:total===0?null:moeda(custo/total*100),
    margemBruta,
    margemPercentual:total===0?null:moeda(margemBruta/total*100)
  };
}
