import test from "node:test";
import assert from "node:assert/strict";
import {calcularPedido} from "../src/domain/calculos.js";
import {validarCPF} from "../src/domain/cpf.js";
import {Pedido} from "../src/domain/Pedido.js";

const itens=[
  {quantidade:2,precoUnitario:29.90,custoUnitario:9.80},
  {quantidade:2,precoUnitario:7.90,custoUnitario:3.00}
];

test("calcula total CMV e margem",()=>{
  const r=calcularPedido({itens,desconto:5,taxaEntrega:6});
  assert.deepEqual(r,{subtotal:75.6,total:76.6,custo:25.6,cmvPercentual:33.42,margemBruta:51,margemPercentual:66.58});
});

test("valida CPF sintético",()=>{
  assert.equal(validarCPF("52998224725"),true);
  assert.equal(validarCPF("11111111111"),false);
});

test("rejeita pedido sem unidade",()=>{
  assert.throws(()=>new Pedido({unidade:"",cpf:"52998224725",itens}),/Unidade obrigatória/);
});

test("rejeita pedido sem itens",()=>{
  assert.throws(()=>calcularPedido({itens:[]}),/Pedido sem itens/);
});
