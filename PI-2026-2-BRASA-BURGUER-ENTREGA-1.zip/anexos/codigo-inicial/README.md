# Brasa Burguer Management

Versão inicial da Entrega 1 do Projeto Integrado 2026/2.

## Integrantes

- Gabriel Rodrigues do Prado - 3º semestre
- Rafaela Rodrigues Oliveira - 1º semestre

## Problema

Operações de food service registram pedidos, clientes, produtos e indicadores em ferramentas separadas. O projeto propõe uma aplicação web multiunidade com regras únicas e verificáveis.

## Tecnologias

- JavaScript com módulos ECMAScript
- Node.js para execução e testes
- PostgreSQL previsto para persistência
- Arquitetura preparada para implantação em nuvem

## Executar

Requisito: Node.js 20 ou superior.

```bash
npm test
npm start
```

## Estrutura

- `src/domain`: regras independentes da interface
- `src/index.js`: exemplo executável
- `test`: testes automatizados

## Matriz resumida

| Disciplina | Aplicação | Evidência |
|---|---|---|
| Linguagem de Programação | Funções, módulos, tipos e erros em JavaScript | Código-fonte |
| Algoritmos e Programação Estruturada | Sequência, seleção, repetição e modularização | Fluxo e funções |
| Matemática Computacional | Total, CMV, margem e CPF | Cálculos e testes |

## Linha de base e incremento

O protótipo anterior possui telas iniciais de painel, pedidos, clientes e produtos. O incremento de 2026/2 organiza as regras em JavaScript, adiciona testes, modelagem orientada a objetos e arquitetura de nuvem.

## Segurança

Nunca envie `.env`, senhas, chaves ou tokens ao repositório. Use `.env.example` apenas como modelo.

## Repositório

Após criar ou confirmar o repositório, copie a URL completa para o formulário oficial e para esta seção.
